﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace шифратор
{
    public partial class MainWindow : Window
    {
        private const string PolybiusSquareKey = "абвгдежзийклмнопрстуфхцчшщъыьэюя";
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_Click(object sender, RoutedEventArgs e)
        {
            string inputText = InputTextBox.Text;
            if (inputText.Length != 16)
            {
                MessageBox.Show("Введите предложение из 16 символов.");
                return;
            }

            string encryptedText = EncryptText(inputText);

            OutputTextBox.Text = encryptedText;
        }

        private string EncryptText(string inputText)
        {
            char[,] matrix = new char[4, 4];
            int index = 0;

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    matrix[i, j] = inputText[index];
                    index++;
                }
            }

            for (int i = 0; i < 4; i += 2)
            {
                for (int j = 0; j < 4; j++)
                {
                    char temp = matrix[i, j];
                    matrix[i, j] = matrix[i + 1, j];
                    matrix[i + 1, j] = temp;
                }
            }

            for (int j = 0; j < 4; j += 2)
            {
                for (int i = 0; i < 4; i++)
                {
                    char temp = matrix[i, j];
                    matrix[i, j] = matrix[i, j + 1];
                    matrix[i, j + 1] = temp;
                }
            }

            StringBuilder encryptedText = new StringBuilder();
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    encryptedText.Append(matrix[i, j]);
                }
            }

            return encryptedText.ToString();
        }
        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            // Получаем текст из первого TextBox
            string inputText = perchek.Text;

            // Получаем ключ шифрования из второго TextBox
            int key = int.Parse(lol.Text);

            // Шифруем текст с помощью шифра Цезаря
            string encryptedText = Encrypt(inputText, key);

            // Выводим зашифрованный текст в третий TextBox
            pirchec.Text = encryptedText;
        }



        private string Encrypt(string inputText, int key)
        {
            // Создаем новый массив символов для хранения зашифрованного текста
            char[] encryptedText = new char[inputText.Length];

            // Шифруем каждый символ входного текста с помощью ключа
            for (int i = 0; i < inputText.Length; i++)
            {
                // Получаем код символа
                int charCode = (int)inputText[i];

                // Шифруем символ с помощью ключа
                int encryptedCharCode = charCode + key;

                // Если зашифрованный код символа выходит за пределы допустимого диапазона, то переносим его в начало диапазона
                if (encryptedCharCode > 'z')
                {
                    encryptedCharCode -= 26;
                }

                // Преобразуем зашифрованный код символа в символ
                char encryptedChar = (char)encryptedCharCode;

                // Добавляем зашифрованный символ в массив зашифрованного текста
                encryptedText[i] = encryptedChar;
            }

            // Преобразуем массив зашифрованного текста в строку
            string encryptedString = new string(encryptedText);

            // Возвращаем зашифрованный текст
            return encryptedString;
        }
        private void EncryptButton_Click(object sender, RoutedEventArgs e)
        {
            string plaintext = InputTextBox1.Text.ToLower();
            StringBuilder ciphertext = new StringBuilder();

            foreach (char c in plaintext)
            {
                if (Char.IsLetter(c))
                {
                    int index = PolybiusSquareKey.IndexOf(c);
                    int row = index / 5 + 1;
                    int column = index % 5 + 1;
                    ciphertext.Append(row.ToString() + column.ToString() + " ");
                }
                else
                {
                    ciphertext.Append(c);
                }
            }

            OutputTextBox1.Text = ciphertext.ToString();
        }

        private void Com_Click(object sender, RoutedEventArgs e)
        {
            string input = Nose.Text;
            List<string> permutations = GetPermutations(input);

            Python.Text = string.Join(Environment.NewLine, permutations);
        }

        private List<string> GetPermutations(string input)
        {
            List<string> permutations = new List<string>();

            if (input.Length == 1)
            {
                permutations.Add(input);
                return permutations;
            }

            foreach (char c in input)
            {
                string remainingChars = new string(input.Where(x => x != c).ToArray());
                List<string> subPermutations = GetPermutations(remainingChars);

                foreach (string subPermutation in subPermutations)
                {
                    permutations.Add(c + subPermutation);
                }
            }

            return permutations;
        }
    }
}